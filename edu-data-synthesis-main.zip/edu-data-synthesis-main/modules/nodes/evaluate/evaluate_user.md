{% if fewshot %}
Example Provided Inputs:
{% else %}
Provided Inputs:
{% endif %}

- `scenario`:
{{scenario}}
- `messages`:
{{messages}}
- `criteria`:
{{criteria}}