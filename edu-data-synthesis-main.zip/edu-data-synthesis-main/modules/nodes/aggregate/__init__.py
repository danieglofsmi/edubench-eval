from modules.nodes.aggregate.aggregate import (
    EvaluationAverage,
    EvaluationMax,
    EvaluationMin,
    EvaluationAggregation,
    EvaluationVoting,
    Debate,
    aggregate_system_template
)