Provided Inputs:

- `scenario`:
{{scenario}}
- `messages`:
{{messages}}
- `criteria`:
{{criteria}}
- `evaluations`:
{{evaluations}}