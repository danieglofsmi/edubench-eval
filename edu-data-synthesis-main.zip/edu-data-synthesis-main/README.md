# edu-data-synthesis
Data Synthesis/Evaluation in Educational Scenarios
